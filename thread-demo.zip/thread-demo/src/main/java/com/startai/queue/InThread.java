package com.startai.queue;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

public class InThread extends Thread{

    @Override
    public void run() {

    }
}
