package com.startai.reflex;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Properties;

public class TestMain {
    public static void main(String[] args) throws ClassNotFoundException {
        //获取class三种方式
        //第一种
        Person person = new Person();
        Class pc = person.getClass();
        System.out.println(pc.getName());
        //第二种
        Class pc2 = Person.class;
        System.out.println(pc2.getName());
        //第三种
        Class pc3 = Class.forName("com.startai.reflex.Person");
        System.out.println(pc3.getName());
        //获取public的属性
        Field[] fields = pc.getFields();
        for (Field f : fields) {
            System.out.println(f.getName());
        }

        //利用反射获取配置文件
        Properties properties = new Properties();
        try {
            properties.load(TestMain.class.getClassLoader().getResourceAsStream("app.properties"));
            System.out.println(properties.getProperty("admin"));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
